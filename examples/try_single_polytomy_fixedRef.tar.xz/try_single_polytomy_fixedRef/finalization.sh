#!/bin/bash
set -euo pipefail

RUN_PATH=/picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/trys/try_single_polytomy_fixedRef

mkdir -p ${RUN_PATH}/final_output

# No regrafting. Consensus output from RunPipelineUseThis.sh is final.
# Copy consensus HAL/MAF/FASTA as final alignment outputs.

cp ${RUN_PATH}/Root/consensus.hal ${RUN_PATH}/final_output/FinalResultAlignment.hal
cp ${RUN_PATH}/Root/consensus.maf ${RUN_PATH}/final_output/FinalResultAlignment.maf
cp ${RUN_PATH}/Root/consensus.fasta ${RUN_PATH}/final_output/FinalResultAlignment.fasta
cp ${RUN_PATH}/Root/Root.fa ${RUN_PATH}/final_output/Root.fa
