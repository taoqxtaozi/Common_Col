#!/bin/bash
set -euo pipefail

RUN_PATH=/picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/trys/try_Root_is_polytomy_fixedRef_RefInDeep_needReroot

mkdir -p ${RUN_PATH}/final_output

# Regrafting workflow

patched_halAppendSubtree=/picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/tool_used/bin/halAppendSubtree

if [[ ! -f "$patched_halAppendSubtree" ]]; then
    echo "Error: bundled executable not found: $patched_halAppendSubtree"
    exit 1
fi
chmod +x "$patched_halAppendSubtree"

root_alltaxa_hal="${RUN_PATH}/Root/FinalResultAlignment.hal"
cp ${RUN_PATH}/Root/consensus.hal "$root_alltaxa_hal"
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in3/consensus.hal Anc_in3 Anc_in3 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in3/Anc_in2/Anc_in2_aln1.hal Anc_in2 Anc_in2 --merge

cactus-hal2maf --outType single --chunkSize 500000 --refGenome CHLUN --noAncestors ${RUN_PATH}/Root/jobstorehal2maf_Root_allTaxa ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/FinalResultAlignment.maf
taxa_args=(CHLUN CATAU COLLI CUCCA GALGA MESUN PTEGU TAUER)
python /picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/maf_to_concat_fasta.py "${taxa_args[@]}" < ${RUN_PATH}/Root/FinalResultAlignment.maf > ${RUN_PATH}/Root/FinalResultAlignment.fasta

mv "$root_alltaxa_hal" ${RUN_PATH}/final_output/FinalResultAlignment.hal
mv ${RUN_PATH}/Root/FinalResultAlignment.maf ${RUN_PATH}/final_output/FinalResultAlignment.maf
mv ${RUN_PATH}/Root/FinalResultAlignment.fasta ${RUN_PATH}/final_output/FinalResultAlignment.fasta
cp ${RUN_PATH}/Root/Root.fa ${RUN_PATH}/final_output/Root.fa
