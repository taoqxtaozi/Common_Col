#!/bin/bash
set -euo pipefail

RUN_PATH=/picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/trys/try_single_polytomy_nofixedRef

mkdir -p ${RUN_PATH}/final_output

# No regrafting is required. Final output handling depends on the root task type.

# Root consensus task: RunPipelineUseThis.sh already produced the final consensus HAL/MAF/FASTA.
# Only copy/rename outputs into final_output.

cp ${RUN_PATH}/Root/consensus.hal ${RUN_PATH}/final_output/FinalResultAlignment.hal
cp ${RUN_PATH}/Root/consensus.maf ${RUN_PATH}/final_output/FinalResultAlignment.maf
cp ${RUN_PATH}/Root/consensus.fasta ${RUN_PATH}/final_output/FinalResultAlignment.fasta
cp ${RUN_PATH}/Root/Root.fa ${RUN_PATH}/final_output/Root.fa
