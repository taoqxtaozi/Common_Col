#!/bin/bash
set -euo pipefail

RUN_PATH=/picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/trys/try_binaryTree_nofixedRef

mkdir -p ${RUN_PATH}/final_output

# No regrafting is required. Final output handling depends on the root task type.

# Root fixed task: the root alignment is produced by cactus as <Root>_aln1.hal.
# Export HAL -> MAF using the final export reference, then convert MAF -> FASTA.

cp ${RUN_PATH}/Root/Root_aln1.hal ${RUN_PATH}/Root/FinalResultAlignment.hal
cactus-hal2maf --outType single --chunkSize 500000 --refGenome CATAU --noAncestors ${RUN_PATH}/Root/jobstorehal2maf_Root_allTaxa ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/FinalResultAlignment.maf
taxa_args=(CATAU CHLUN COLLI GALGA MESUN)
python /picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/maf_to_concat_fasta.py "${taxa_args[@]}" < ${RUN_PATH}/Root/FinalResultAlignment.maf > ${RUN_PATH}/Root/FinalResultAlignment.fasta

mv ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/final_output/FinalResultAlignment.hal
mv ${RUN_PATH}/Root/FinalResultAlignment.maf ${RUN_PATH}/final_output/FinalResultAlignment.maf
mv ${RUN_PATH}/Root/FinalResultAlignment.fasta ${RUN_PATH}/final_output/FinalResultAlignment.fasta
cp ${RUN_PATH}/Root/Root.fa ${RUN_PATH}/final_output/Root.fa
