#Command to build instruction.txt:

cd rerun
bash "$ConsensusExtractionPATH/make_plan.sh" --tree-file ./aln.tre --noFixedRef 1  --paths ./genome.txt --threads 20 --common_workers 5 --guide-seed 20260922

