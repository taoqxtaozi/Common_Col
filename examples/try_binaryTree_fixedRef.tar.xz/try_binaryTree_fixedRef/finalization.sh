#!/bin/bash
set -euo pipefail

RUN_PATH=/picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/trys/try_binaryTree_fixedRef

mkdir -p ${RUN_PATH}/final_output

# No regrafting. Fixed Cactus HAL is the final alignment.
# Export final MAF and FASTA from this HAL.

cp ${RUN_PATH}/Root/Root_aln1.hal ${RUN_PATH}/final_output/FinalResultAlignment.hal
cactus-hal2maf --outType single --chunkSize 500000 --refGenome GALGA --noAncestors ${RUN_PATH}/Root/jobstorehal2maf_Root_final ${RUN_PATH}/final_output/FinalResultAlignment.hal ${RUN_PATH}/final_output/FinalResultAlignment.maf
taxa_args=(GALGA CATAU CHLUN COLLI MESUN)
python /picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/maf_to_concat_fasta.py "${taxa_args[@]}" < ${RUN_PATH}/final_output/FinalResultAlignment.maf > ${RUN_PATH}/final_output/FinalResultAlignment.fasta
cp ${RUN_PATH}/Root/Root.fa ${RUN_PATH}/final_output/Root.fa
