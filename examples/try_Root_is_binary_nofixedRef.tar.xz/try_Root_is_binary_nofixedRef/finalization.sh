#!/bin/bash
set -euo pipefail

RUN_PATH=/picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/trys/try_Root_is_binary_nofixedRef

mkdir -p ${RUN_PATH}/final_output

# Regrafting workflow

patched_halAppendSubtree=/picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/tool_used/bin/halAppendSubtree
if [[ ! -f "$patched_halAppendSubtree" ]]; then
    echo "Error: bundled executable not found"
    exit 1
fi
chmod +x "$patched_halAppendSubtree"

root_alltaxa_hal="${RUN_PATH}/Root/FinalResultAlignment.hal"
cp ${RUN_PATH}/Root/Root_aln1.hal "$root_alltaxa_hal"
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/consensus.hal Anc_in2 Anc_in2 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/interior26/interior26_aln1.hal interior26 interior26 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/interior25/interior25_aln1.hal interior25 interior25 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/interior10/consensus.hal interior10 interior10 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/interior10/interior12/interior12_aln1.hal interior12 interior12 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/interior10/interior15/consensus.hal interior15 interior15 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/interior10/interior9/consensus.hal interior9 interior9 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/interior10/interior9/interior2/interior2_aln1.hal interior2 interior2 --merge
"$patched_halAppendSubtree" ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/Anc_in2/interior10/interior9/interior4/consensus.hal interior4 interior4 --merge

cactus-hal2maf --outType single --chunkSize 500000 --refGenome PHORU --noAncestors ${RUN_PATH}/Root/jobstorehal2maf_Root_allTaxa ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/Root/FinalResultAlignment.maf
taxa_args=(PHORU ACACH APAVI BUCRH CARCR CATAU COLLI COLST CORBR FALPE GALGA GEOFO HALLE LEPDI MANVI MELUN MERNU MESUN NESNO OPHHO PICPU PODCR PTEGU TAEGU TYTAL)
python /picb/phylcomb/yzy/taoqx/cactus-bin-v3.3.0/Common_Col/maf_to_concat_fasta.py "${taxa_args[@]}" < ${RUN_PATH}/Root/FinalResultAlignment.maf > ${RUN_PATH}/Root/FinalResultAlignment.fasta

mv ${RUN_PATH}/Root/FinalResultAlignment.hal ${RUN_PATH}/final_output/FinalResultAlignment.hal
mv ${RUN_PATH}/Root/FinalResultAlignment.maf ${RUN_PATH}/final_output/FinalResultAlignment.maf
mv ${RUN_PATH}/Root/FinalResultAlignment.fasta ${RUN_PATH}/final_output/FinalResultAlignment.fasta
cp ${RUN_PATH}/Root/Root.fa ${RUN_PATH}/final_output/Root.fa
